<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
</head>
<body>
<center>
    <h1>首页</h1>
    <table>
        <tr>
            <td><a href="/winter/eleven/week1/index.php/Home/Index/show">点击进入展示页面</a></td>
        </tr>
        <tr>
            <td><a href="/winter/eleven/week1/index.php/Home/Index/add">点击进入添加页面</a></td>
        </tr>
    </table>
</center>
</body>
</html>