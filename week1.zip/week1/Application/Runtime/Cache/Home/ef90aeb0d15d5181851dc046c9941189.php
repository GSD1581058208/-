<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>展示页面</title>
</head>
<body>
<center>
    <table>
        <tr>
            <td>ID</td>
            <td>学号</td>
            <td>姓名</td>
            <td>性别</td>
            <td>身份证号</td>
            <td>所在班级</td>
            <td>状态</td>
            <td>操作</td>
        </tr>
        <?php if(is_array($list)): foreach($list as $key=>$v): ?><tr>
            <td><?php echo ($v["id"]); ?></td>
            <td><?php echo ($v["student"]); ?></td>
            <td><?php echo ($v["name"]); ?></td>
            <td><?php echo ($v["sex"]); ?></td>
            <td><?php echo ($v["number"]); ?></td>
            <td><?php echo ($v["c_id"]); ?></td>
            <td><?php echo ($v["state"]); ?></td>
            <td><a href="/winter/eleven/week1/index.php/Home/Index/update/id/<?php echo ($v["id"]); ?>">修改</a> | <a href="/winter/eleven/week1/index.php/Home/Index/delete/id/<?php echo ($v["id"]); ?>">删除</a></td>
        </tr><?php endforeach; endif; ?>
    </table>
    <?php echo ($page); ?>
    <span><a href="/winter/eleven/week1/index.php/Home/Index/add">继续添加</a></span>
</center>
</body>
</html>