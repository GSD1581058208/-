<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>添加页面</title>
</head>
<body>
<center>
    <form action="/winter/eleven/week1/index.php/Home/Index/add_do" method="post">
    <table>
        <tr>
            <td>学号：</td>
            <td><input type="text" name="student"></td>
        </tr>
        <tr>
            <td>姓名：</td>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>性别：</td>
            <td><input type="text" name="sex"></td>
        </tr>
        <tr>
            <td>身份证号：</td>
            <td><input type="text" name="number"></td>
        </tr>
        <tr>
            <td>所在班级：</td>
            <td><select name="c_id" id="">
                <option value="">请选择班级</option>
                <option value="1604A">1604A</option>
                <option value="1604B">1604B</option>
                <option value="1604C">1604C</option>
            </select></td>
        </tr>
        <tr>
            <td>状态：</td>
            <td><input type="radio" name="state" value="在校">在校<input type="radio" name="state" value="毕业">毕业
                <input type="radio" name="state" value="休学">休学
                <input type="radio" name="state" value="退学">退学</td>
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit" value="确认添加"></td>
        </tr>
    </table>
    </form>
</center>
</body>
</html>