<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    //首页
    public function index(){
        $this->display(index);
    }
    //展示页面
    public function show(){
        $User=M('student');
        $count=$User->count();
        $Page=new \Think\Page($count,3);
        $show=$Page->show();
        $list=$User->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->display("show");
    }
    //添加页面
    public function add(){
        $this->display(add);
    }
    //处理添加
    public function add_do(){
//        $class = I('class');
//        $month = I('month');
//        $course = I('course');
        $student = I('student');
        if($student == ""){
            $this->error("学号不能为空！",U("add"),1);
        }
        $name = I('name');
        $mu = $name.length;
        if($name == ""){
            $this->error("姓名不能为空！",U("add"),1);
        }else if($mu>6){
            $this->error("学生姓名不能超过6个字符！",U("add"),2);
        }
        $sex = I('sex');
        if($sex == ""){
            $this->error("性别不能为空！",U("add"),1);
        }
        $number = I('number');
        if($number == ""){
            $this->error("身份证号不能为空！",U("add"),1);
        }
        $c_id = I('c_id');
        if($c_id == ""){
            $this->error("所在班级不能为空！",U("add"),1);
        }
        $state = I('state');
        if($state == ""){
            $this->error("状态不能为空！",U("add"),1);
        }
//        var_dump($course);die;


        $model = M("student");
//        $data['class'] = $class;
//        $data['month'] = $month;
//        $data['course'] = $course;
        $data['student'] = $student;
        $data['name'] = $name;
        $data['sex'] = $sex;
        $data['number'] = $number;
        $data['c_id'] = $c_id;
        $data['state'] = $state;
//        var_dump($data);die;
        $res = $model->add($data);
//        var_dump($res);die;
        if($res){
            $this->success("添加成功！",U("show"),1);
        }else{
            $this->error("添加失败！",U("add"),1);
        }
    }
    //处理删除
    public function delete(){
        $id = I('get.id');
        $data['id'] = $id;
        $res = M("student")->where($data)->delete();
        if($res){
            $this->success("删除成功！",U("show"),1);
        }else{
            $this->error("删除失败！",U("show"),1);
        }
    }
}